"""
        >>>>>>>    Ejercicio Funciones I   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios Funciones I  <<<<<<")                                                            
print (f"\n","Ejercicio 1: \n")
print ("""
Escribir una función que muestre por pantalla el saludo ¡Hola amiga!
cada vez que se la invoque.                                             

def saludo():
    print("Hola amiga!")

saludo()            \n""")

def saludo():
    print("Hola amiga!")

saludo()