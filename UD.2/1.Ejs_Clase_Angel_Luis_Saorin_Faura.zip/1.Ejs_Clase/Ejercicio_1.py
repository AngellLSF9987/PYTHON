"""
        >>>>>>>    Ejercicios Clase   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios Clase   <<<<<<")                                                           
print (f"\n","Ejercicio 1: \n")
print ("""Escribir un programa que pregunte el nombre del usuario en la consola y un número entero e imprima por pantalla en 
líneas distintas el nombre del usuario tantas veces como el número introducido.\n""")

print ("""# Solicitar nombre y número entero al usuario

                nombre = input("Introduce tu nombre: ")
                num = int(input("Introduce un número entero: "))

# Bucle for para imprimir el nombre tantas veces como el número indicado
            
                for i in range(num):
                print(nombre)\n\n""")

# Solicitar nombre y número entero al usuario
nombre = input("Introduce tu nombre: \n")
num = int(input("Introduce un número entero: \n"))

# Bucle for para imprimir el nombre tantas veces como el número indicado
for i in range(num):
    print(nombre)





