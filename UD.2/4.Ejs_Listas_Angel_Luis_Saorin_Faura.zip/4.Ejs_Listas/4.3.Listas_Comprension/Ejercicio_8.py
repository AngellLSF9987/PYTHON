"""
        >>>>>>>    Ejercicios de Listas   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Listas   <<<<<<\n")                                                           
print ("""Ejercicio 8:
Crear una lista con las primeras letras de una está lista: palabras = ["manzana",
"banana", "cereza"]

# Lista de palabras
palabras = ["manzana", "banana", "cereza"]

# Crear una lista con las primeras letras de cada palabra
iniciales = [palabra[0] for palabra in palabras]

# Mostrar la lista de primeras letras
print("Las primeras letras de las palabras son:", iniciales+".")\n""")

# Lista de palabras
palabras = ["manzana", "banana", "cereza"]

# Crear una lista con las primeras letras de cada palabra
iniciales = [palabra[0] for palabra in palabras]

# Mostrar la lista de primeras letras
print("Las primeras letras de las palabras son:", iniciales+".\n")
