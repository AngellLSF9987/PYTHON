"""
        >>>>>>>    Ejercicios de Cadenas   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Cadenas   <<<<<<")                                                           
print (f"\n","Ejercicio 3: \n")
print ("""
# A. Crea una tupla con los números del 1 al 10.

        # • Inicializar la tupla.

                num = (1,2,3,4,5,6,7,8,9,10)

# B. Calcula la suma de todos los números.

        # • Inyectar la tupla dentro de una lista para poder tratar los valores

                total = sum(list(num))

        # •  Imprimir resultado de la suma de la tupla.

                print("El resultado de la suma de la tupla es: " + str (total) +".\n")"\n""")

# A. Crea una tupla con los números del 1 al 10.

# • Inicializar la tupla.

num = (1,2,3,4,5,6,7,8,9,10)

# B. Calcula la suma de todos los números.

# • Inyectar la tupla dentro de una lista para poder tratar los valores

total = sum(list(num))

# •  Imprimir resultado de la suma de la tupla.

print("El resultado de la suma de la tupla es: " + str (total) +".\n")

