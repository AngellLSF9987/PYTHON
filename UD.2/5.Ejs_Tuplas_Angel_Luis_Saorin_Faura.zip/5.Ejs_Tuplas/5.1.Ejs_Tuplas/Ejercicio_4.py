"""
        >>>>>>>    Ejercicios de Cadenas   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Cadenas   <<<<<<")                                                           
print (f"\n","Ejercicio 4: \n")
print ("""
# A. Crea una tupla de tuplas para representar una matriz de 3x3.

        # • Inicializar la tupla.

                matriz = (
                        (1,2,3),
                        (4,5,6),
                        (7,8,9)
                )

# B. Imprime el elemento en la segunda fila y tercera columna.

        # • Acceder al elemento en la segunda fila y tercera columna

                item = matriz[1][2]

        # •  Imprimir resultado del elemento buscado en la tupla.

                print("El item buscado en la segunda fila y tercera columna es:", item,".\n")"\n""")

# A. Crea una tupla de tuplas para representar una matriz de 3x3.

# • Inicializar la tupla.

matriz = (
        (1,2,3),
        (4,5,6),
        (7,8,9)
)

# B. Imprime el elemento en la segunda fila y tercera columna.

# • Acceder al elemento en la segunda fila y tercera columna

item = matriz[1][2]

# •  Imprimir resultado del elemento buscado en la tupla.

print("El item buscado en la segunda fila y tercera columna es:", item,".\n")