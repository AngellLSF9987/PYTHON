"""
        >>>>>>>    Ejercicios de Tuplas   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Tuplas   <<<<<<")                                                            
print (f"\n","Ejercicio 1: \n")
print ("""
A. Crea una tupla con los nombres de los días de la semana.
     
     dias = ("Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo")
     print(dias)
     
B. Imprime el tercer día de la semana.
     
     print(dias[2])
     
C. Imprime los días de la semana en orden inverso."
     
     print(dias[::-1])     \n""")

# A. Crea una tupla con los nombres de los días de la semana.

dias = ("Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo")
print(dias)

# B. Imprime el tercer día de la semana.

print(dias[2])

# C. Imprime los días de la semana en orden inverso.

print(dias[::-1])