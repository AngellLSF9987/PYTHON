"""
        >>>>>>>    Ejercicios de Cadenas   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Cadenas   <<<<<<")                                                           
print (f"\n","Ejercicio 5: \n")
print ("""
# A. Crea una lista de números.

        # • Inicializar el objeto tipo de lista.

                lista = list[1,2,3,4,5]

# B. Convierte la lista en una tupla.

        # • Formatear la lista a tupla

                tupla = (lista)

                print("La tupla original de números es:", tupla,".\n")

# C. Multiplica cada elemento de la tupla por 2 y guarda el resultado en
# una nueva tupla.

        # • Inyectamos la tupla dentro de una lista para poder realizar la operación del producto de los valores.

                tupla_multiplicacion = tupla(item * 2 for item in tupla)

        # • Imprimir resultado de la nueva tupla.

                print("La nueva tupla obtenida tiene los valores numéricos:", tupla_multiplicacion,".\n")"\n""")

# A. Crea una lista de números.

# • Inicializar el objeto tipo de lista.

lista = list[1,2,3,4,5]

# B. Convierte la lista en una tupla.

# • Formatear la lista a tupla

tupla = (lista)

print("La tupla original de números es:", tupla,".\n")

# C. Multiplica cada elemento de la tupla por 2 y guarda el resultado en
# una nueva tupla.

# • Inyectamos la tupla dentro de una lista para poder realizar la operación del producto de los valores.

tupla_multiplicacion = tupla(item * 2 for item in tupla)

# • Imprimir resultado de la nueva tupla.

print("La nueva tupla obtenida tiene los valores numéricos:", tupla_multiplicacion,".\n")

