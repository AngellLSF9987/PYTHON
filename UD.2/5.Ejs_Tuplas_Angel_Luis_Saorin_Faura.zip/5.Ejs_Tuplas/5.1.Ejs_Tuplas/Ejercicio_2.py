"""
        >>>>>>>    Ejercicios de Tuplas   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Tuplas   <<<<<<")                                                           
print (f"\n","Ejercicio 2: \n")
print ("""
A. Crea una tupla con tus datos personales (nombre, apellido, edad).

    # •  Creación de la tupla con nombre, apellido y edad

        mis_datos = ("Juan", "Pérez", 30)

B. Imprime una frase que incluya tus datos 
    
     # •  Imprimir una frase que incluya los datos de la tupla

        print("Me llamo", mis_datos[0], mis_datos[1], "y tengo", mis_datos[2], "años.\n")\n""")

# A. Crea una tupla con tus datos personales (nombre, apellido, edad).

    # Creación de la tupla con nombre, apellido y edad

mis_datos = ("Juan", "Pérez", 30)

# B. Imprime una frase que incluya tus datos

    # Imprimir una frase que incluya los datos de la tupla

print("Me llamo", mis_datos[0], mis_datos[1], "y tengo", mis_datos[2], "años.\n")
