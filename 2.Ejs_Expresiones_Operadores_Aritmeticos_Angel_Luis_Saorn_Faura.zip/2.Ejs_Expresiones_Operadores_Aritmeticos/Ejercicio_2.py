"""
        >>>>>>>    Ejercicios de Expresiones y Operadores Aritméticos  <<<<<<
                                                                            """
print (f"\n>>>>>>>    Ejercicios de Expresiones y Operadores Aritméticos   <<<<<<\n")                                                           
print (f"Ejercicio 2. Transforma los textos siguientes en código de Python: \n")

print (f"a) m es dividido entre 3 y almacenado en la variable p\n")

m = input("¿Introduce un valor para m?\n")
print (f"m =",m)

print (f"Realizamos un casting que convierta el valor de m, introducido como string, a un dato int.\n")
print (f"                     p = int(m)/3\n")
p = int(m)/3

print (f"El valor de p es: ",p)

print (f"\nb) m menos 6 almacenado en la variable q\n")

m = input("¿Introduce un valor para m?\n")
print (f"m =",m)
print (f"                     p = int(m)-6\n")
q = int(m)-6

print (f"El valor de q es: ",q)