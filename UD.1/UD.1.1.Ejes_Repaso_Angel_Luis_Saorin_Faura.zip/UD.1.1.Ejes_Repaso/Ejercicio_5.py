"""
        >>>>>>>    Ejercicios Repaso   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios Repaso   <<<<<<")                                                           
print (f"\n","Ejercicio 5: \n")
print ("""Imprimir los números de 1 al 100 con while y con for."\n""")

print("""
# Inicializar el contador

        num = 1

# Usar un bucle while para imprimir números del 1 al 100

        while num <= 100:
                print(num, end =" ")
                num += 1
    
# Punto de ruptura después de imprimir el último número

        if num > 100:
                break

# Separador para claridad en la salida

        print("Fin del bucle WHILE.\n")

# Usar un bucle for para imprimir números del 1 al 100

        for num in range(1, 101):
                print(num, end =" ")
    
# Separador para claridad en la salida

        print("Fin del bucle FOR.\n") \n\n""")

# Inicializar el contador

num = 1

# Usar un bucle while para imprimir números del 1 al 100

while (num <= 100):
    print(num, end =" ")
    num += 1
# Punto de ruptura después de imprimir el último número

    if (num > 100):
        break

# Separador para claridad en la salida

print("\nFin del bucle WHILE.\n")

# Usar un bucle for para imprimir números del 1 al 100

for num in range(1, 101):
    print(num, end =" ")
    
# Separador para claridad en la salida

print("\n Fin del bucle FOR.\n")

