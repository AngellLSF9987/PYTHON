"""
        >>>>>>>    Ejercicios Repaso   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios Repaso   <<<<<<")                                                           
print (f"\n","Ejercicio 2: \n")
print ("""Se ingresan por teclado tres números, si todos los valores ingresados son menores a 10, imprimir en pantalla la leyenda 
"Algún número es menor a diez"."\n""")

print ("""Este ejercicio es igual que el ejercicio 1 sólo cambia el mensaje de salida cuando todos los números son menores""")