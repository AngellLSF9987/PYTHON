Ejercicios Módulos
        
    1. Modificar el programa de la calculadora para añadirle 3 funcionalidades
       más, utilizando el módulo math.

    2. Crear un programa que consista en adivinar números.
        a. El número se debe generar de manera aleatoria
        b. El usuario cuando introduzca el número, se le debe indicar, si es
           el número, si es menor o mayor, y así poder ir cercando el
           número.

    3. Crear un programa para crear contraseñas seguras.
        a. El usuario debe introducir la longitud que desea de la contraseña.

    4. Crear un programa que genere un boleto de lotería ganador.
        a. Generar 5 números de una tabla de 54 (números del 1 al 54) y
           uno más (número clave) de una tabla de 10 (del 0 al 9). Los
           números no pueden ser repetidos.

        b. Imprimir la fecha del día de hoy. (Modulo datetime)