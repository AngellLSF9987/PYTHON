"""
        >>>>>>>    Ejercicios de Variables   <<<<<<
                                                             """
                                                             
print (f">>>>>>>    Ejercicios de Variables   <<<<<<")                                                           
                                                             
print (f"\n","Ejercicio 1: \n")
                       
print (f"a) Crea un variable llamada perros y asígnale el valor que el usuario introduzca por teclado: \n")

perros = input("¿Cuántos perros tienes? ")
print (f"Tengo: ",perros,"\n")

print (type(perros))

print (f"b) Crea una variable llamada comida y asígnale el valor 200.\n")

comida = 200
print (f"El valor de la comida: ",comida,"\n")

print (type(comida))

print (f"c) Muestra el contenido de la variable perros. \n")

print (f"El usuario respondió que el número de perros que tenía: ",perros,"\n")

print (f"d) Modifica el valor de la variable perros a 150.\n")

perros = 150
print (perros,"\n")
print (type(perros))

print (f"e) Copia el valor de la variable perros en la variable comida.","\n")

print (f"La sentencia que realizaría la copia del valor sería: \n","comida = perros \n")

print (f"f) Imprime el valor de las dos variables con print().\n")

print (f"El valor de la comida: ",comida, "\nEl número de perros que el usuario ha contestado que tiene: ",perros)


