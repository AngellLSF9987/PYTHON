"""
        >>>>>>>    Ejercicios de Variables   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Variables   <<<<<<") 
print (f"\n","Ejercicio 3: \n")

"""
print (f"Escriba un programa que solicite al usuario tres letras y los muestre
al revés. \n")

letra1 = input("¿Primera letra? ")
print (f"Respuesta: ",letra1,"\n")

letra2 = input("¿Segunda letra? ")
print (f"Respuesta: ",letra2,"\n")

letra3 = input("¿Tercera letra? ")
print (f"Respuesta: ",letra3,"\n")


print (f"Las tres por orden de petición han sido: \n",letra1,", ",letra2,", ",letra3,"\n")
print (f"Las tres por orden inverso de petición han sido: \n",letra3,", ",letra2,", ",letra1,"\n")

                                                                                                    """


print (f"Escriba un programa que solicite al usuario tres letras y los muestre al revés. \n")

letra1 = input("¿Primera letra? ")
print (f"Respuesta: ",letra1,"\n")

letra2 = input("¿Segunda letra? ")
print (f"Respuesta: ",letra2,"\n")

letra3 = input("¿Tercera letra? ")
print (f"Respuesta: ",letra3,"\n")

print (f"Las tres por orden de petición han sido: \n",letra1,", ",letra2,", ",letra3,"\n")
print (f"Las tres por orden inverso de petición han sido: \n",letra3,", ",letra2,", ",letra1,"\n")
