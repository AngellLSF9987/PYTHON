print("hola")
print("mesa")

print (type ("mesa"))

num = int(8.570)
print(num)

num1 = float(8) 
print (num1)

a,b,c = 37,"Angel", "Saorin"
print (a,b,c);

print (type (a))
print (type (b))
print (type (c)) 