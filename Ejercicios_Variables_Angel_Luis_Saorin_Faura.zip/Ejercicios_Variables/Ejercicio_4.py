"""
        >>>>>>>    Ejercicios de Variables   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Variables   <<<<<<") 
print (f"\n","Ejercicio 4: \n")

print (f"Crea un programa que pregunte al usuario: ¿Cómo te llamas? y guarde el nombre en la variable x. El programa debe responder: Encantado de conocerte, x. \n")

x = input("¿Cómo te llamas?")
print (f"Encantado de conocerte",x,".\n")