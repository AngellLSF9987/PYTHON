"""
        >>>>>>>    Ejercicios de Variables   <<<<<<
                                                             """
print (f">>>>>>>    Ejercicios de Variables   <<<<<<") 
print (f"\n","Ejercicio 2: \n")

print (f"a) Escribe la palabra elefante dentro de una variable llamada animal. \n")
print (f"La sentencia  que declara >animal< como variable y que su valor sea >elefante< sería:\n")
print (f"animal = ('elefante')","print (animal)\n")
print (f"RESULTADO:\n")
animal = ("elefante")
print (animal,"\n")

print (f"b) Escribe la palabra rosa dentro de una variable llamada color. \n")
print (f"La sentencia  que declara >color< como variable y que su valor sea >rosa< sería:\n")
print (f"animal = ('elefante')","print (animal)\n")

print (f"RESULTADO:\n")
color = ("rosa")
print (color,"\n")

print (f"c) Crea una variable llamada imagina donde se almacenen las dos variables anteriores: animal y color dando como resultado el valor elefanterosa. \n")
 
print (f"La sentencia  que declara >imagina< como variable y que su valor sea >elefanterosa< sería:\n") 
print (f"imagina = (animal,color)\n")

print (f"RESULTADO:\n")
imagina = (animal,color)

print (f"d) En la variable imagina intercala un espacio en blanco para separar las dos palabras.\n")

print (f"La sentencia que declara >imagina< como variable y que su valor sea >elefante rosa< sería:\n")
print (f"imagina = (animal,color) \n print (animal, AQUÍ SE DEBE CONCATENAR CON UNAS COMILLAS DOBLES O SIMPLES, ESAPCIADAS ENTRE SÍ, color)\n")

print (f"RESULTADO:\n")
imagina = (animal,color)
print (animal,'', color,"\n")
