
    4. Crear la clase Autor:

        a. Variables de instancia: Nombre, año de nacimiento.
        b. Instanciar 3 autores.

    Crear la clase Libro.

        c. Variables de instancia: titulo, autor, año de publicación, leído=False.
        d. Métodos:

            i. Comprobar si el libro esta leído
            ii. Cambiar el valor a leído del libro.

        e. Instanciar 5 libros y pasarle como parámetro el autor instanciado anteriormente.
        f. Llamar a los métodos creados y comprobar su cambio de valor.
        g. Mostrar la información del libro
        h. Crear una lista, almacenar los libros en ella, y tras recorrerla
           mostrar los libros de uno de los autores creados anteriormente.