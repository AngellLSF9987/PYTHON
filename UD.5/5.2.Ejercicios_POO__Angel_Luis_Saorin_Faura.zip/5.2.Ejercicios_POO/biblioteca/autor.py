
# Clase Autor

class Autor:
    def __init__(self, nombre, ano_nacimiento):
        self.nombre = nombre
        self.ano_nacimiento = ano_nacimiento

