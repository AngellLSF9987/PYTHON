
    3. Modificar el ejercicio de la Calculadora, para que sea una clase.

        a. Tiene que seguir teniendo el while para que siga pidiendo de manera 
           infinita las funciones hasta que se le índique la opción de salir.