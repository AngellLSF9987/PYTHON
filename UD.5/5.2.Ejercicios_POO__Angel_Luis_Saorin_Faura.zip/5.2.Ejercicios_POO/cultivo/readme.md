
    2. Crear clase Cultivo.

        a. Variables de instancia: nombre, variedad, fecha de siembra, fecha
           esperada de cosecha y estado de cosecha = “No iniciado”.

        b. Métodos:

            i. Iniciar cosecha. Se muestra la cosecha que esta en curso y
               se cambia el valor de la variable estado de cosecha a En
               curso.

            ii. Finalizar cosecha. Se muestra que cosecha ha finalizado y
                se cambia el valor de la variable estado de cosecha a
                Finalizado.

            iii. Calcular días restantes para la cosecha, desde la fecha de
                 hoy a la fecha estimada de cosecha. Importar el módulo para
                 trabajar con fechas.

        c. Crear diferentes cultivos, y utilizar los métodos para cambiar el
           estado de cosecha.

        d. Crear una lista para almacenar los cultivos.
        
        e. Mostrar la información de los cultivos. (nombre y estado de la cosecha)