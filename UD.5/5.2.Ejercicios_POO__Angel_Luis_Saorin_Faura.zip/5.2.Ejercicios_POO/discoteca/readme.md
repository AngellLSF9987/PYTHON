
    1. Crear clase Discoteca.

        a. Variables de instancia: Nombre, horario de apertura, código de
           vestimenta (booleano).

        b. Método:

            i. Comprobar si la discoteca esta abierta. Se puede importar
               el módulo para trabajar con fechas.

            ii. Comprobar si la discoteca tiene código de vestimenta.

        c. Instanciar 2 discotecas.

        d. Comprobar si dejarían entrar en sandalias de playa, y bermudas a
           Tom “El guiri” a las 16:00.

        e. Tom sigue sin cambiarse de ropa, pero ahora va a probar a la otra
           discoteca, comprobar si lo dejan pasar.