"""
        >>>>>>>    Ejercicios de Estructuras Repetitivas. BUCLE  > FOR <  <<<<<<
                                                                                    """

print (f"\n>>>>>>>    Ejercicios de Estructuras Repetitivas. BUCLE  > FOR <   <<<<<<\n")                                                           
print ("""Ejercicio 1: Crea un programa utilizando el bucle for en que hay que mostrar
por pantalla números del 1 al 10.\n""")

print("""
        for i in range(1, 11):
                print(i)
\n\n""")

for i in range(1, 11):
    print(i)



